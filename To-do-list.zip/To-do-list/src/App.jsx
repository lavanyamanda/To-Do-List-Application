import { useState } from 'react';
import Header from './components/Header';
import ToDoList from './components/ToDoList';
import './App.css';

function App() {
  const [todos, setTodos] = useState([
    { id: 1, text: 'Learn React', completed: false },
    { id: 2, text: 'Build a project', completed: false }
  ]);
  const [newTodo, setNewTodo] = useState('');

  // Add a new to-do
  const handleAdd = () => {
    if (newTodo.trim() === '') return;
    const newItem = {id: Date.now(), text: newTodo, completed: false};
    setTodos([...todos, newItem]);
    setNewTodo('');
  };

  // Toggle completed state
  const handleToggle = (id) => {
    setTodos(
      todos.map((todo) => todo.id === id ? { ...todo, completed: !todo.completed } : todo)
    );
  };

  // Delete a to-do
  const handleDelete = (id) => {
    setTodos(
      todos.filter((todo) => todo.id !== id));
  };

  // Edit to-do text
  const handleEdit = (id, newText) => {
    setTodos(
      todos.map((todo) => todo.id === id ? { ...todo, text: newText } : todo)
    );
  };

  return (
    <div className="container">
      <Header />
      <div className="add-todo">
        <input type="text" placeholder="Add new task..." value={newTodo}
          onChange={(e) => setNewTodo(e.target.value)}  />
        <button onClick={handleAdd}>Add</button>
      </div>
      <ToDoList
        todos={todos}
        onToggle={handleToggle}
        onDelete={handleDelete}
        onEdit={handleEdit}
      />
    </div>
  );
}

export default App;
