import { useState } from 'react';

function ToDoItem({ todo, onToggle, onDelete, onEdit }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);

  const handleEditSubmit = (e) => {
    e.preventDefault();
    if (editText.trim() === '') return;
    onEdit(todo.id, editText);
    setIsEditing(false);
  };

  return (
    <li className={`todo-item ${todo.completed ? 'completed' : ''}`}>
      {isEditing ? (
        <form onSubmit={handleEditSubmit}>
          <input type="text"  value={editText} onChange={(e) => setEditText(e.target.value)}/>
          <button type="submit">Save</button>
          <button onClick={() => setIsEditing(false)} type="button">Cancel</button>
        </form> ) : ( <>
          <input type="checkbox" checked={todo.completed} onChange={() => onToggle(todo.id)} />
          <span onDoubleClick={() => setIsEditing(true)} > {todo.text} </span>
          <button onClick={() => onDelete(todo.id)}>Delete</button>
        </>
      )}
    </li>
  );
}

export default ToDoItem;
